
#include "std_lib_facilities.h"
#include "test.h"

int main()
{

	// Her kan du teste koden og funksjonene dine, 
	// Ingenting som skrives her blir automatisk rettet, du tester her for din egen del


	return 0;
}
