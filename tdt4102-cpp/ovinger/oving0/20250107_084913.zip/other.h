#pragma once

void messageFromOtherFile();