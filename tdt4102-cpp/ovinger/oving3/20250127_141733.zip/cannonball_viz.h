#pragma once

void cannonBallViz(double targetPosition,
				   int fieldLength,
				   double initVelocityX,
				   double initVelocityY,
				   int timeSteps);
