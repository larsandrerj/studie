#include "std_lib_facilities.h"

int main()
{
	// Her skal du teste koden din underveis for å sikre deg at den funker slik forventet
	return 0;
}