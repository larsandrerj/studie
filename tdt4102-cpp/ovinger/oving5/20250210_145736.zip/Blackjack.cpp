#include "Blackjack.h"

// Her kan du lage dine funksjons- og klasseimplementasjoner for å lage blackjack